# Country Service – Integration Microservice

REST → SOAP → MySQL integration built with Spring Boot 3.3 / Java 17.

`POST {"name":"kenya"}` → sentence-case → SOAP `CountryISOCode` → SOAP `FullCountryInfo` → persisted in MySQL (`CountryInfo` + `Language`) → full CRUD over REST.

## 1. Architecture

```
Client ─HTTP─▶ CountryController ─▶ CountryService ─▶ CountryInfoSoapClient ─SOAP/HTTP─▶ CountryInfoService.wso
 (MVC)          validation, status     orchestration     timeout → retry → circuit breaker → cache
                codes                       │
                                            ▼
                                   CountryInfoRepository ─JPA─▶ MySQL
```

| Layer | Package | Responsibility |
|---|---|---|
| Controller | `controller` | HTTP mapping, bean validation, status codes only |
| Service | `service` | Orchestration (normalise → ISO lookup → full info → upsert), transactions, metrics |
| Client | `client` | SOAP envelope building/parsing, resilience, caching (anti-corruption layer) |
| Repository / Model | `repository`, `model` | JPA entities `CountryInfo` (1) ─ (n) `Language` |
| DTO | `dto` | API contracts, entities never leak over the wire |
| Exception | `exception` | Typed errors + one `@RestControllerAdvice` producing a uniform `ErrorResponse` |
| Logging | `logging` | `X-Correlation-Id` filter feeding MDC `traceId` |

### Key design decisions and trade-offs

| Decision | Why | Trade-off |
|---|---|---|
| Hand-built SOAP 1.1 envelopes over `RestClient` (no WSDL codegen) | Only two operations are used; avoids generated-code build step and extra dependencies; XML parsing is hardened (no DOCTYPE/XXE) and unit-tested | If many operations are added, switch to `spring-ws` + JAXB generated from the WSDL |
| Stateless pods | Any replica can serve any request → horizontal scaling via HPA, safe rolling updates | State lives in MySQL |
| SOAP calls **outside** DB transactions (`TransactionTemplate` only around the upsert) | A slow upstream never pins a DB connection / exhausts the Hikari pool | Slightly more code than a single `@Transactional` |
| Timeouts (3 s connect / 8 s read) + Resilience4j retry (3 tries, exponential backoff) + circuit breaker | Bounded latency, rides out transient faults, fails fast (503) when the provider is down instead of piling up threads | Worst-case request ≈ 3 × 8 s + backoff when the provider is slow |
| Retry only on `ExternalServiceException`; **not** on "country not found" or open circuit | Business 404s are not transient; open circuit must fail fast | |
| Caffeine cache for ISO code and full info (24 h) | Reference data rarely changes; cuts upstream calls under load and protects the provider | Per-pod cache (not shared); a Redis cache would give shared hit-rate if needed |
| Upsert by unique `iso_code` (201 on create, 200 on refresh) + retry on unique-key race | Idempotent POST, no duplicates under concurrent requests | |
| Pagination on list (`page`,`size`≤100,`sort`) | Bounded response sizes | |
| Queueing intentionally **not** added | The flow is a synchronous request/response of ~2 fast calls; a queue would add infrastructure and complexity without benefit. If bulk ingestion is needed, accept a list and process through Kafka/SQS workers | |
| `ddl-auto=update` | Fast to run for the exercise | For production use Flyway/Liquibase and `validate` |

### Failure behaviour

| Situation | Result |
|---|---|
| Invalid / blank / malformed body | `400` with field-level `details` |
| Country not known to the SOAP service | `404` |
| Unknown id on GET/PUT/DELETE | `404` |
| SOAP timeout / 5xx / bad XML (after retries) | `502` |
| Circuit breaker open | `503` (fails immediately) |
| Database unavailable | `503` |
| Anything unexpected | `500` generic message (details only in logs) |

Every error body: `timestamp, status, error, message, path, traceId, details[]`.

### Observability

* **Logs**: text locally; JSON (`SPRING_PROFILES_ACTIVE=json`, default in the container) with `traceId`. One access line per request plus a log line for each SOAP call and DB write. Send `X-Correlation-Id` to propagate your own id; it is echoed in the response.
* **Metrics** (`/actuator/prometheus`): HTTP server metrics with histograms, JVM, Hikari, `soap.client.calls{operation,outcome}`, `country.lookup{outcome}`, Resilience4j retry and circuit-breaker metrics.
* **Health**: `/actuator/health/liveness` and `/actuator/health/readiness` (readiness includes the database).
* **API docs**: Swagger UI at `/swagger-ui.html`.

## 2. Running and testing

### Prerequisites
Java 17, Maven 3.9+, Docker (for MySQL), optionally SoapUI.

### Option A – Docker Compose (app + MySQL)
```bash
docker compose up --build
```

### Option B – local app, MySQL in Docker
```bash
docker run -d --name mysql -e MYSQL_ROOT_PASSWORD=root -e MYSQL_DATABASE=countrydb -p 3306:3306 mysql:8.0
mvn spring-boot:run
```
Defaults: `root/root` on `localhost:3306/countrydb`. Override via `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`.

### Automated tests
```bash
mvn test
```
* `NameFormatterTest` – sentence-case conversion
* `SoapXmlTest` – request building, response parsing, not-found, malformed XML, XXE rejection
* `CountryApiIntegrationTest` – full create/read/update/delete + error cases through the real MVC/JPA stack (H2 in MySQL mode, SOAP client mocked)

### Manual end-to-end test (calls the real SOAP service)
```bash
# 1. create (name is normalised: kenya -> Kenya)
curl -i -X POST localhost:8080/api/v1/countries -H 'Content-Type: application/json' -d '{"name":"kenya"}'
# 2. list (paged)
curl 'localhost:8080/api/v1/countries?page=0&size=10&sort=name,asc'
# 3. by id
curl localhost:8080/api/v1/countries/1
# 4. update
curl -X PUT localhost:8080/api/v1/countries/1 -H 'Content-Type: application/json' \
  -d '{"name":"Kenya","capitalCity":"Nairobi","phoneCode":"254","continentCode":"AF","currencyIsoCode":"KES","languages":[{"isoCode":"swa","name":"Swahili"},{"isoCode":"eng","name":"English"}]}'
# 5. delete
curl -i -X DELETE localhost:8080/api/v1/countries/1
# errors
curl -i -X POST localhost:8080/api/v1/countries -H 'Content-Type: application/json' -d '{"name":""}'        # 400
curl -i -X POST localhost:8080/api/v1/countries -H 'Content-Type: application/json' -d '{"name":"Narnia"}'  # 404
curl localhost:8080/actuator/health/readiness
curl localhost:8080/actuator/prometheus | grep soap_client
```

The equivalent SOAP calls can be reproduced in SoapUI using the WSDL
`http://webservices.oorsprong.org/websamples.countryinfo/CountryInfoService.wso?WSDL` (operations `CountryISOCode` and `FullCountryInfo`).

## 3. API summary

| Method | Path | Description | Success |
|---|---|---|---|
| POST | `/api/v1/countries` | `{ "name": "kenya" }` – look up via SOAP and store | 201 (new) / 200 (refreshed) |
| GET | `/api/v1/countries` | Paged list | 200 |
| GET | `/api/v1/countries/{id}` | Single country with languages | 200 |
| PUT | `/api/v1/countries/{id}` | Update fields (and replace languages when supplied) | 200 |
| DELETE | `/api/v1/countries/{id}` | Delete (languages cascade) | 204 |

## 4. Kubernetes

* Manifests: `k8s/`  · Script: `scripts/deploy.sh`
* Deploy guide: [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md)
* Troubleshooting guide: [`docs/TROUBLESHOOTING.md`](docs/TROUBLESHOOTING.md)

## 5. Configuration reference

| Env var | Default | Purpose |
|---|---|---|
| `DB_URL`, `DB_USERNAME`, `DB_PASSWORD` | localhost MySQL, root/root | Database |
| `DB_POOL_SIZE` | 10 | Hikari max pool |
| `JPA_DDL_AUTO` | update | Schema management |
| `SOAP_URL` | oorsprong endpoint | SOAP endpoint |
| `SOAP_CONNECT_TIMEOUT_MS` / `SOAP_READ_TIMEOUT_MS` | 3000 / 8000 | Upstream timeouts |
| `SPRING_PROFILES_ACTIVE` | – (`json` in container) | JSON logging |
| `APP_LOG_LEVEL` | INFO | App log level |

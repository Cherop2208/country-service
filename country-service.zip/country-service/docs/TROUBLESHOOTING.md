# Troubleshooting on Kubernetes

Set once: `alias k='kubectl -n ncba'`

## 1. First look
```bash
k get pods -o wide
k get events --sort-by=.lastTimestamp | tail -20
k describe pod <pod>
k logs deploy/country-service --tail=100          # add -f to follow, --previous for the last crashed container
```

## 2. Symptom → cause → fix

| Symptom | Likely cause | Check | Fix |
|---|---|---|---|
| `ImagePullBackOff` / `ErrImagePull` | Wrong image name/tag, private registry, image not loaded into local cluster | `k describe pod` → Events | Fix tag; add `imagePullSecrets`; `minikube image load` / `kind load docker-image` |
| `Pending` | Not enough CPU/memory, PVC not bound | `k describe pod`; `k get pvc` | Lower requests, add nodes, ensure a default StorageClass |
| `CrashLoopBackOff` | Cannot connect to DB, bad config, OOM | `k logs --previous` | See DB and OOM rows below |
| `OOMKilled` (`k describe pod` → Last State) | Memory limit too low | `k top pod` | Raise `limits.memory`, tune `JAVA_OPTS` (`-XX:MaxRAMPercentage`) |
| Pod `Running` but `0/1 Ready` | Readiness probe failing – readiness includes the **database** | `k describe pod` (probe events); `k exec deploy/country-service -- wget -qO- localhost:8080/actuator/health/readiness` | Fix DB connectivity/credentials |
| Logs: `Communications link failure` / `Access denied for user` | MySQL not up yet, wrong `DB_URL`, wrong secret | `k get pods -l app=mysql`; `k get secret country-service-secret -o jsonpath='{.data.DB_USERNAME}' \| base64 -d` | Wait for MySQL; fix ConfigMap/Secret then `k rollout restart deploy/country-service`. Note: MySQL only reads `MYSQL_USER/PASSWORD` on **first** initialisation – if you changed the password afterwards, change it inside MySQL or delete the PVC |
| `502 Bad Gateway` from API | SOAP provider timing out / returning errors | Logs: `Upstream SOAP failure`; metric `soap_client_calls_seconds_count{outcome!="success"}` | Check egress (below); raise `SOAP_READ_TIMEOUT_MS`; provider outage → wait |
| `503` "temporarily unavailable" | Circuit breaker **open** (≥50 % failures in last 20 calls) – auto half-opens after 30 s | `curl .../actuator/prometheus \| grep resilience4j_circuitbreaker_state` | Fix upstream; no action needed once it recovers |
| `503` "Data store unavailable" | DB down or connection pool exhausted | `k logs`; `hikaricp_connections_pending` metric | Restore DB; check `replicas × DB_POOL_SIZE` vs MySQL `max_connections` |
| `404` for a valid country | SOAP service does not know that name | Logs: `Unknown country` | Try the spelling used by the service (e.g. `United States`) – verify in SoapUI |
| Service reachable inside cluster but not outside | Ingress/port-forward issue | `k get ingress`; `k get endpoints country-service` | Empty endpoints → pods not Ready or selector mismatch; verify ingress class and host entry |
| HPA shows `<unknown>` | metrics-server missing or no CPU requests | `k describe hpa country-service`; `kubectl top pods` | Install metrics-server |
| Rollout stuck | New pods not becoming Ready | `k rollout status deploy/country-service`; `k describe rs` | `k rollout undo deploy/country-service` then fix and redeploy |

## 3. Tracing a single request
Every response carries `X-Correlation-Id` (also in error bodies as `traceId`). Logs are JSON, so:
```bash
curl -i -X POST localhost:8080/api/v1/countries -H 'Content-Type: application/json' -d '{"name":"kenya"}'
# note X-Correlation-Id: <id>
k logs -l app=country-service --tail=-1 | grep <id>
```
You will see: the access line (status, durationMs), the SOAP calls (`SOAP call CountryISOCode …`), and the DB write (`Country persisted id=…`).

## 4. Connectivity tests from inside the cluster
```bash
# Database reachable from an app pod?
k exec deploy/country-service -- sh -c 'timeout 3 bash -c "</dev/tcp/mysql.ncba.svc.cluster.local/3306" && echo DB port open'
# MySQL itself
k exec -it statefulset/mysql -- mysql -uroot -p -e 'show databases; select count(*) from countrydb.countries;'
# Egress to the SOAP provider
k run curl --rm -it --image=curlimages/curl --restart=Never -- \
  curl -sS -m 10 -o /dev/null -w '%{http_code}\n' 'http://webservices.oorsprong.org/websamples.countryinfo/CountryInfoService.wso?WSDL'
# DNS
k run dns --rm -it --image=busybox:1.36 --restart=Never -- nslookup mysql.ncba.svc.cluster.local
```
If the SOAP check fails only inside the cluster, look at NetworkPolicies and corporate egress/proxy rules.

## 5. Useful runtime endpoints
```bash
k port-forward svc/country-service 8080:80
curl localhost:8080/actuator/health                      # overall
curl localhost:8080/actuator/health/readiness            # DB included
curl localhost:8080/actuator/metrics/soap.client.calls   # upstream latency/outcomes
curl localhost:8080/actuator/prometheus | grep -E 'resilience4j|hikari|http_server_requests'
```
Raise log detail temporarily: `k set env deploy/country-service APP_LOG_LEVEL=DEBUG` (and set back to INFO afterwards).

## 6. Recovery actions
```bash
k rollout restart deploy/country-service      # bounce pods (zero downtime: maxUnavailable=0)
k rollout undo deploy/country-service         # previous revision
k delete pod <pod>                            # replace a single bad pod
k exec -it <pod> -- sh                        # shell in (JRE image)
```

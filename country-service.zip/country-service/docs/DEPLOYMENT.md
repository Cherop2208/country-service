# Deploying to Kubernetes

## What gets created (namespace `ncba`)

| File | Resources |
|---|---|
| `k8s/00-namespace.yaml` | Namespace |
| `k8s/01-config.yaml` | ConfigMap (non-secret settings), Secret (DB credentials – placeholder values) |
| `k8s/02-mysql.yaml` | MySQL 8 StatefulSet (5 Gi PVC) + headless Service `mysql` |
| `k8s/03-app.yaml` | Deployment (2 replicas, rolling update, probes, resource limits), Service, HPA (2–10 pods @ 70 % CPU), PodDisruptionBudget |
| `k8s/04-ingress.yaml` | NGINX Ingress for host `country-service.local` |

## Prerequisites
* A cluster (minikube, kind, Docker Desktop, or a managed cluster) and `kubectl` pointing at it
* Docker
* `metrics-server` installed (needed by the HPA; `minikube addons enable metrics-server`)
* An ingress controller (optional; `minikube addons enable ingress`)
* A container registry you can push to (not needed for a local cluster)

## Option 1 – scripted
```bash
# Local cluster (minikube / kind / docker-desktop): no registry needed
LOCAL_CLUSTER=true DB_PASSWORD='appPass123' MYSQL_ROOT_PASSWORD='rootPass123' ./scripts/deploy.sh

# Remote cluster
REGISTRY=docker.io/<user> TAG=1.0.0 DB_PASSWORD='appPass123' MYSQL_ROOT_PASSWORD='rootPass123' ./scripts/deploy.sh
```
The script builds the image, pushes it (or loads it into minikube/kind), creates the secret from your environment, waits for MySQL, deploys the app, and waits for the rollout.

## Option 2 – manual
```bash
docker build -t <registry>/country-service:1.0.0 . && docker push <registry>/country-service:1.0.0

kubectl apply -f k8s/00-namespace.yaml
kubectl apply -f k8s/01-config.yaml
kubectl -n ncba create secret generic country-service-secret \
  --from-literal=DB_USERNAME=countryapp --from-literal=DB_PASSWORD='appPass123' \
  --from-literal=MYSQL_ROOT_PASSWORD='rootPass123' --dry-run=client -o yaml | kubectl apply -f -
kubectl apply -f k8s/02-mysql.yaml
kubectl -n ncba rollout status statefulset/mysql
sed 's|IMAGE_PLACEHOLDER|<registry>/country-service:1.0.0|' k8s/03-app.yaml | kubectl apply -f -
kubectl apply -f k8s/04-ingress.yaml
kubectl -n ncba rollout status deployment/country-service
```

## Verify
```bash
kubectl -n ncba get pods,svc,hpa
kubectl -n ncba port-forward svc/country-service 8080:80 &
curl localhost:8080/actuator/health/readiness
curl -X POST localhost:8080/api/v1/countries -H 'Content-Type: application/json' -d '{"name":"kenya"}'
```
Via ingress (minikube): add `<minikube ip> country-service.local` to `/etc/hosts`, then `curl http://country-service.local/api/v1/countries`.

## Operations

| Task | Command |
|---|---|
| Scale manually | `kubectl -n ncba scale deploy/country-service --replicas=4` (HPA will manage it afterwards) |
| Roll out a new version | `kubectl -n ncba set image deploy/country-service country-service=<registry>/country-service:1.0.1` |
| Watch rollout | `kubectl -n ncba rollout status deploy/country-service` |
| Roll back | `kubectl -n ncba rollout undo deploy/country-service` |
| Change config | edit `k8s/01-config.yaml`, apply, then `kubectl -n ncba rollout restart deploy/country-service` |
| Remove app | `./scripts/undeploy.sh` (`PURGE=true` also deletes MySQL data) |

## Production notes
* Replace the placeholder Secret with sealed-secrets / External Secrets / a vault; never commit real passwords.
* Use a managed MySQL (or an operator) with backups instead of the single-replica StatefulSet.
* Switch `JPA_DDL_AUTO` to `validate` and manage schema with Flyway/Liquibase.
* Pin image tags (never `latest`); add a NetworkPolicy allowing only ingress → app and app → MySQL/egress to the SOAP host.
* The app is stateless, so scaling out only needs more DB connections: keep `replicas × DB_POOL_SIZE` below MySQL `max_connections`.

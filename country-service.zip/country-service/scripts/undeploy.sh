#!/usr/bin/env bash
# Remove the application (and optionally the database + namespace).
#   ./scripts/undeploy.sh          # app only
#   PURGE=true ./scripts/undeploy.sh   # also MySQL, PVC data and namespace
set -euo pipefail
NAMESPACE="${NAMESPACE:-ncba}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

kubectl delete -f "$ROOT/k8s/04-ingress.yaml" --ignore-not-found
sed "s|IMAGE_PLACEHOLDER|x|" "$ROOT/k8s/03-app.yaml" | kubectl delete --ignore-not-found -f -
if [[ "${PURGE:-false}" == "true" ]]; then
  kubectl delete -f "$ROOT/k8s/02-mysql.yaml" --ignore-not-found
  kubectl -n "$NAMESPACE" delete pvc -l app=mysql --ignore-not-found
  kubectl delete namespace "$NAMESPACE" --ignore-not-found
fi

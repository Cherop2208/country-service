#!/usr/bin/env bash
# Build, publish and deploy country-service to Kubernetes.
#
# Usage:
#   REGISTRY=docker.io/youruser TAG=1.0.0 DB_PASSWORD='s3cret' MYSQL_ROOT_PASSWORD='r00t' ./scripts/deploy.sh
#   LOCAL_CLUSTER=true ./scripts/deploy.sh          # minikube/kind/docker-desktop: skip push
#
set -euo pipefail

NAMESPACE="${NAMESPACE:-ncba}"
TAG="${TAG:-1.0.0}"
REGISTRY="${REGISTRY:-}"
LOCAL_CLUSTER="${LOCAL_CLUSTER:-false}"
IMAGE="${REGISTRY:+$REGISTRY/}country-service:$TAG"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo ">> Building image $IMAGE"
docker build -t "$IMAGE" "$ROOT"

if [[ "$LOCAL_CLUSTER" == "true" ]]; then
  command -v minikube >/dev/null && minikube image load "$IMAGE" || true
  command -v kind >/dev/null && kind load docker-image "$IMAGE" || true
else
  [[ -n "$REGISTRY" ]] || { echo "Set REGISTRY (or LOCAL_CLUSTER=true)"; exit 1; }
  echo ">> Pushing $IMAGE"
  docker push "$IMAGE"
fi

echo ">> Applying namespace and config"
kubectl apply -f "$ROOT/k8s/00-namespace.yaml"
kubectl apply -f "$ROOT/k8s/01-config.yaml"

# Override the placeholder secret with real values when supplied (never commit these).
if [[ -n "${DB_PASSWORD:-}" && -n "${MYSQL_ROOT_PASSWORD:-}" ]]; then
  echo ">> Creating/updating secret from environment"
  kubectl -n "$NAMESPACE" create secret generic country-service-secret \
    --from-literal=DB_USERNAME="${DB_USERNAME:-countryapp}" \
    --from-literal=DB_PASSWORD="$DB_PASSWORD" \
    --from-literal=MYSQL_ROOT_PASSWORD="$MYSQL_ROOT_PASSWORD" \
    --dry-run=client -o yaml | kubectl apply -f -
else
  echo "!! DB_PASSWORD / MYSQL_ROOT_PASSWORD not set: using placeholder secret (demo only)"
fi

echo ">> Deploying MySQL"
kubectl apply -f "$ROOT/k8s/02-mysql.yaml"
kubectl -n "$NAMESPACE" rollout status statefulset/mysql --timeout=300s

echo ">> Deploying application ($IMAGE)"
sed "s|IMAGE_PLACEHOLDER|$IMAGE|" "$ROOT/k8s/03-app.yaml" | kubectl apply -f -
kubectl apply -f "$ROOT/k8s/04-ingress.yaml" || echo "(ingress skipped: no ingress controller?)"
kubectl -n "$NAMESPACE" rollout status deployment/country-service --timeout=300s

echo ">> Done."
kubectl -n "$NAMESPACE" get pods,svc,hpa
echo "Try:  kubectl -n $NAMESPACE port-forward svc/country-service 8080:80"

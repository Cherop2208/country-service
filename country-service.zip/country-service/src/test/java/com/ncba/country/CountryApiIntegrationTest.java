package com.ncba.country;

import com.ncba.country.client.CountryInfoSoapClient;
import com.ncba.country.client.FullCountryInfoResult;
import com.ncba.country.exception.ExternalServiceException;
import com.ncba.country.exception.UnknownCountryException;
import com.ncba.country.repository.CountryInfoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/** End-to-end through controller -> service -> JPA (H2 in MySQL mode), with the SOAP client mocked. */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class CountryApiIntegrationTest {

    @Autowired MockMvc mvc;
    @Autowired CountryInfoRepository repository;
    @MockBean CountryInfoSoapClient soapClient;

    @BeforeEach
    void setUp() {
        repository.deleteAll();
    }

    private FullCountryInfoResult kenya() {
        return new FullCountryInfoResult("KE", "Kenya", "Nairobi", "254", "AF", "KES", "http://flag/Kenya.jpg",
                List.of(new FullCountryInfoResult.LanguageInfo("swa", "Swahili")));
    }

    @Test
    void fullCrudFlow() throws Exception {
        when(soapClient.fetchIsoCode("Kenya")).thenReturn("KE");
        when(soapClient.fetchFullCountryInfo("KE")).thenReturn(kenya());

        // create (name is normalised to sentence case before the SOAP call)
        String body = mvc.perform(post("/api/v1/countries").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"kenya\"}"))
                .andExpect(status().isCreated())
                .andExpect(header().exists("Location"))
                .andExpect(header().exists("X-Correlation-Id"))
                .andExpect(jsonPath("$.isoCode").value("KE"))
                .andExpect(jsonPath("$.languages[0].name").value("Swahili"))
                .andReturn().getResponse().getContentAsString();
        long id = Long.parseLong(body.replaceAll(".*\"id\":(\\d+).*", "$1"));

        // posting again refreshes rather than duplicating
        mvc.perform(post("/api/v1/countries").contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"KENYA\"}"))
                .andExpect(status().isOk());

        mvc.perform(get("/api/v1/countries")).andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(1));
        mvc.perform(get("/api/v1/countries/" + id)).andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Kenya"));

        mvc.perform(put("/api/v1/countries/" + id).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"Kenya\",\"capitalCity\":\"Nairobi City\",\"languages\":[{\"isoCode\":\"eng\",\"name\":\"English\"}]}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.capitalCity").value("Nairobi City"))
                .andExpect(jsonPath("$.languages.length()").value(1))
                .andExpect(jsonPath("$.languages[0].name").value("English"));

        mvc.perform(delete("/api/v1/countries/" + id)).andExpect(status().isNoContent());
        mvc.perform(get("/api/v1/countries/" + id)).andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404));
    }

    @Test
    void blankNameIsBadRequest() throws Exception {
        mvc.perform(post("/api/v1/countries").contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"  \"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.details").isNotEmpty());
    }

    @Test
    void malformedJsonIsBadRequest() throws Exception {
        mvc.perform(post("/api/v1/countries").contentType(MediaType.APPLICATION_JSON).content("{oops"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void unknownCountryIs404() throws Exception {
        when(soapClient.fetchIsoCode(anyString())).thenThrow(new UnknownCountryException("Country 'Narnia' was not found"));
        mvc.perform(post("/api/v1/countries").contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"narnia\"}"))
                .andExpect(status().isNotFound());
    }

    @Test
    void upstreamFailureIs502() throws Exception {
        when(soapClient.fetchIsoCode(anyString())).thenThrow(new ExternalServiceException("boom"));
        mvc.perform(post("/api/v1/countries").contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"kenya\"}"))
                .andExpect(status().isBadGateway())
                .andExpect(jsonPath("$.message").value("Could not retrieve data from the country information provider."));
    }

    @Test
    void healthEndpointIsUp() throws Exception {
        mvc.perform(get("/actuator/health/readiness")).andExpect(status().isOk());
    }
}

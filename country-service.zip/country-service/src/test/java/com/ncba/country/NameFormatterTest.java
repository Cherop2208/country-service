package com.ncba.country;

import com.ncba.country.util.NameFormatter;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class NameFormatterTest {

    @Test
    void convertsToSentenceCase() {
        assertEquals("Kenya", NameFormatter.toSentenceCase("kenya"));
        assertEquals("Tanzania", NameFormatter.toSentenceCase("TANZANIA"));
        assertEquals("South Africa", NameFormatter.toSentenceCase("  south   AFRICA "));
    }

    @Test
    void handlesNull() {
        assertNull(NameFormatter.toSentenceCase(null));
    }
}

package com.ncba.country;

import com.ncba.country.client.FullCountryInfoResult;
import com.ncba.country.client.SoapXml;
import com.ncba.country.exception.ExternalServiceException;
import com.ncba.country.exception.UnknownCountryException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SoapXmlTest {

    private static final String ISO_RESPONSE = """
            <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body>
            <m:CountryISOCodeResponse xmlns:m="http://www.oorsprong.org/websamples.countryinfo">
            <m:CountryISOCodeResult>KE</m:CountryISOCodeResult></m:CountryISOCodeResponse></soap:Body></soap:Envelope>""";

    private static final String FULL_RESPONSE = """
            <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body>
            <m:FullCountryInfoResponse xmlns:m="http://www.oorsprong.org/websamples.countryinfo"><m:FullCountryInfoResult>
            <m:sISOCode>KE</m:sISOCode><m:sName>Kenya</m:sName><m:sCapitalCity>Nairobi</m:sCapitalCity>
            <m:sPhoneCode>254</m:sPhoneCode><m:sContinentCode>AF</m:sContinentCode>
            <m:sCurrencyISOCode>KES</m:sCurrencyISOCode><m:sCountryFlag>http://flag/Kenya.jpg</m:sCountryFlag>
            <m:Languages><m:tLanguage><m:sISOCode>swa</m:sISOCode><m:sName>Swahili</m:sName></m:tLanguage></m:Languages>
            </m:FullCountryInfoResult></m:FullCountryInfoResponse></soap:Body></soap:Envelope>""";

    @Test
    void parsesIsoCode() {
        assertEquals("KE", SoapXml.parseIsoCode(ISO_RESPONSE, "Kenya"));
    }

    @Test
    void unknownCountryRaisesNotFound() {
        String xml = ISO_RESPONSE.replace(">KE<", ">Country not found in the database<");
        assertThrows(UnknownCountryException.class, () -> SoapXml.parseIsoCode(xml, "Narnia"));
    }

    @Test
    void parsesFullCountryInfoWithoutMixingLanguageFields() {
        FullCountryInfoResult r = SoapXml.parseFullCountryInfo(FULL_RESPONSE, "KE");
        assertEquals("KE", r.isoCode());
        assertEquals("Kenya", r.name());
        assertEquals("Nairobi", r.capitalCity());
        assertEquals("KES", r.currencyIsoCode());
        assertEquals(1, r.languages().size());
        assertEquals("swa", r.languages().get(0).isoCode());
    }

    @Test
    void malformedXmlIsExternalFailure() {
        assertThrows(ExternalServiceException.class, () -> SoapXml.parseIsoCode("<broken", "Kenya"));
    }

    @Test
    void doctypeIsRejected() {
        String xxe = "<!DOCTYPE x [<!ENTITY e SYSTEM \"file:///etc/passwd\">]><a>&e;</a>";
        assertThrows(ExternalServiceException.class, () -> SoapXml.parseIsoCode(xxe, "Kenya"));
    }

    @Test
    void requestEscapesInput() {
        assertTrue(SoapXml.isoCodeRequest("A<b>").contains("A&lt;b&gt;"));
    }
}

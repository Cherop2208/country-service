package com.ncba.country.exception;

/** A stored country does not exist (maps to HTTP 404). */
public class CountryNotFoundException extends RuntimeException {
    public CountryNotFoundException(Long id) {
        super("Country with id " + id + " was not found");
    }
}

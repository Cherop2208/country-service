package com.ncba.country.exception;

/** The upstream SOAP service failed (timeout, 5xx, malformed response). Retryable. Maps to 502. */
public class ExternalServiceException extends RuntimeException {
    public ExternalServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public ExternalServiceException(String message) {
        super(message);
    }
}

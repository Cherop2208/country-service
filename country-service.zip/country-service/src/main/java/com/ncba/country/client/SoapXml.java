package com.ncba.country.client;

import com.ncba.country.exception.ExternalServiceException;
import com.ncba.country.exception.UnknownCountryException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

/** Builds SOAP 1.1 envelopes and parses the CountryInfoService responses (namespace-agnostic, XXE-safe). */
public final class SoapXml {

    public static final String NS = "http://www.oorsprong.org/websamples.countryinfo";
    static final String NOT_FOUND_MARKER = "not found";

    private SoapXml() {}

    public static String isoCodeRequest(String countryName) {
        return envelope("<web:CountryISOCode><web:sCountryName>" + escape(countryName)
                + "</web:sCountryName></web:CountryISOCode>");
    }

    public static String fullCountryInfoRequest(String isoCode) {
        return envelope("<web:FullCountryInfo><web:sCountryISOCode>" + escape(isoCode)
                + "</web:sCountryISOCode></web:FullCountryInfo>");
    }

    private static String envelope(String body) {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"" + NS + "\">"
                + "<soapenv:Header/><soapenv:Body>" + body + "</soapenv:Body></soapenv:Envelope>";
    }

    public static String parseIsoCode(String xml, String requestedName) {
        Element root = parse(xml);
        Element result = firstByLocalName(root, "CountryISOCodeResult");
        if (result == null) {
            throw new ExternalServiceException("SOAP response missing CountryISOCodeResult");
        }
        String code = result.getTextContent() == null ? "" : result.getTextContent().trim();
        if (code.isEmpty() || code.toLowerCase().contains(NOT_FOUND_MARKER)) {
            throw new UnknownCountryException("Country '" + requestedName + "' was not found");
        }
        return code;
    }

    public static FullCountryInfoResult parseFullCountryInfo(String xml, String isoCode) {
        Element root = parse(xml);
        Element result = firstByLocalName(root, "FullCountryInfoResult");
        if (result == null) {
            throw new ExternalServiceException("SOAP response missing FullCountryInfoResult");
        }
        String name = childText(result, "sName");
        if (name == null || name.toLowerCase().contains(NOT_FOUND_MARKER)) {
            throw new UnknownCountryException("No country information found for ISO code '" + isoCode + "'");
        }
        List<FullCountryInfoResult.LanguageInfo> languages = new ArrayList<>();
        NodeList langs = result.getElementsByTagNameNS("*", "tLanguage");
        for (int i = 0; i < langs.getLength(); i++) {
            Element l = (Element) langs.item(i);
            languages.add(new FullCountryInfoResult.LanguageInfo(childText(l, "sISOCode"), childText(l, "sName")));
        }
        return new FullCountryInfoResult(childText(result, "sISOCode"), name, childText(result, "sCapitalCity"),
                childText(result, "sPhoneCode"), childText(result, "sContinentCode"),
                childText(result, "sCurrencyISOCode"), childText(result, "sCountryFlag"), languages);
    }

    private static Element parse(String xml) {
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            f.setNamespaceAware(true);
            f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            f.setXIncludeAware(false);
            f.setExpandEntityReferences(false);
            Document d = f.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
            return d.getDocumentElement();
        } catch (Exception e) {
            throw new ExternalServiceException("Unable to parse SOAP response", e);
        }
    }

    private static Element firstByLocalName(Element root, String local) {
        NodeList nl = root.getElementsByTagNameNS("*", local);
        return nl.getLength() == 0 ? null : (Element) nl.item(0);
    }

    /** Text of the direct child with the given local name (avoids mixing country and language fields). */
    private static String childText(Element parent, String local) {
        for (Node n = parent.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n instanceof Element e && local.equals(e.getLocalName())) {
                String t = e.getTextContent();
                return t == null ? null : t.trim();
            }
        }
        return null;
    }

    private static String escape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }
}

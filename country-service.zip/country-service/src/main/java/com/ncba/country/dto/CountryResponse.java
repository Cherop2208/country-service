package com.ncba.country.dto;

import com.ncba.country.model.CountryInfo;

import java.time.Instant;
import java.util.List;

public record CountryResponse(
        Long id,
        String isoCode,
        String name,
        String capitalCity,
        String phoneCode,
        String continentCode,
        String currencyIsoCode,
        String countryFlag,
        List<LanguageResponse> languages,
        Instant createdAt,
        Instant updatedAt) {

    public record LanguageResponse(Long id, String isoCode, String name) {
    }

    public static CountryResponse from(CountryInfo c) {
        return new CountryResponse(c.getId(), c.getIsoCode(), c.getName(), c.getCapitalCity(), c.getPhoneCode(),
                c.getContinentCode(), c.getCurrencyIsoCode(), c.getCountryFlag(),
                c.getLanguages().stream().map(l -> new LanguageResponse(l.getId(), l.getIsoCode(), l.getName())).toList(),
                c.getCreatedAt(), c.getUpdatedAt());
    }
}

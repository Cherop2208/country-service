package com.ncba.country.controller;

import com.ncba.country.dto.CountryRequest;
import com.ncba.country.dto.CountryResponse;
import com.ncba.country.dto.CountryUpdateRequest;
import com.ncba.country.dto.PageResponse;
import com.ncba.country.service.CountryService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;

@RestController
@RequestMapping("/api/v1/countries")
public class CountryController {

    private final CountryService service;

    public CountryController(CountryService service) {
        this.service = service;
    }

    /** POST {"name":"kenya"} -> looks up via SOAP and stores. 201 when new, 200 when an existing record was refreshed. */
    @PostMapping
    public ResponseEntity<CountryResponse> create(@Valid @RequestBody CountryRequest request) {
        CountryService.SaveResult result = service.lookupAndSave(request.name());
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(result.country().id()).toUri();
        return result.created()
                ? ResponseEntity.created(location).body(result.country())
                : ResponseEntity.ok().location(location).body(result.country());
    }

    @GetMapping
    public PageResponse<CountryResponse> findAll(@PageableDefault(size = 20, sort = "name") Pageable pageable) {
        return service.findAll(pageable);
    }

    @GetMapping("/{id}")
    public CountryResponse findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PutMapping("/{id}")
    public CountryResponse update(@PathVariable Long id, @Valid @RequestBody CountryUpdateRequest request) {
        return service.update(id, request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}

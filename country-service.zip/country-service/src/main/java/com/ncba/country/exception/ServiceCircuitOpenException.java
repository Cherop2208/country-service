package com.ncba.country.exception;

/** Circuit breaker is open: fail fast, do not retry. Maps to 503. */
public class ServiceCircuitOpenException extends ExternalServiceException {
    public ServiceCircuitOpenException(String message, Throwable cause) {
        super(message, cause);
    }
}

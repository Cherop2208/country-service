package com.ncba.country.service;

import com.ncba.country.client.CountryInfoSoapClient;
import com.ncba.country.client.FullCountryInfoResult;
import com.ncba.country.dto.CountryResponse;
import com.ncba.country.dto.CountryUpdateRequest;
import com.ncba.country.dto.PageResponse;
import com.ncba.country.exception.CountryNotFoundException;
import com.ncba.country.model.CountryInfo;
import com.ncba.country.model.Language;
import com.ncba.country.repository.CountryInfoRepository;
import com.ncba.country.util.NameFormatter;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;

@Service
public class CountryService {

    private static final Logger log = LoggerFactory.getLogger(CountryService.class);

    public record SaveResult(CountryResponse country, boolean created) {
    }

    private final CountryInfoSoapClient soapClient;
    private final CountryInfoRepository repository;
    private final TransactionTemplate tx;
    private final MeterRegistry registry;

    public CountryService(CountryInfoSoapClient soapClient, CountryInfoRepository repository,
                          PlatformTransactionManager txManager, MeterRegistry registry) {
        this.soapClient = soapClient;
        this.repository = repository;
        this.tx = new TransactionTemplate(txManager);
        this.registry = registry;
    }

    /**
     * Steps 3-6: sentence-case the name, resolve ISO code (SOAP), fetch full info (SOAP), upsert into MySQL.
     * SOAP calls run outside any DB transaction so slow upstream calls never hold a DB connection.
     */
    public SaveResult lookupAndSave(String rawName) {
        String name = NameFormatter.toSentenceCase(rawName);
        log.info("Processing country lookup rawName='{}' normalised='{}'", rawName, name);
        String isoCode = soapClient.fetchIsoCode(name);
        FullCountryInfoResult info = soapClient.fetchFullCountryInfo(isoCode);
        SaveResult result;
        try {
            result = tx.execute(s -> upsert(info));
        } catch (DataIntegrityViolationException race) {
            log.warn("Concurrent insert for isoCode={}, retrying as update", info.isoCode());
            result = tx.execute(s -> upsert(info));
        }
        registry.counter("country.lookup", "outcome", result.created() ? "created" : "updated").increment();
        log.info("Country persisted id={} isoCode={} created={}", result.country().id(), result.country().isoCode(), result.created());
        return result;
    }

    private SaveResult upsert(FullCountryInfoResult info) {
        var existing = repository.findByIsoCode(info.isoCode());
        boolean created = existing.isEmpty();
        CountryInfo entity = existing.orElseGet(CountryInfo::new);
        entity.setIsoCode(info.isoCode());
        entity.setName(info.name());
        entity.setCapitalCity(info.capitalCity());
        entity.setPhoneCode(info.phoneCode());
        entity.setContinentCode(info.continentCode());
        entity.setCurrencyIsoCode(info.currencyIsoCode());
        entity.setCountryFlag(info.countryFlag());
        entity.replaceLanguages(info.languages().stream().map(l -> new Language(l.isoCode(), l.name())).toList());
        CountryInfo saved = repository.save(entity);
        return new SaveResult(CountryResponse.from(saved), created);
    }

    @Transactional(readOnly = true)
    public PageResponse<CountryResponse> findAll(Pageable pageable) {
        return PageResponse.from(repository.findAll(pageable).map(CountryResponse::from));
    }

    @Transactional(readOnly = true)
    public CountryResponse findById(Long id) {
        return repository.findById(id).map(CountryResponse::from).orElseThrow(() -> new CountryNotFoundException(id));
    }

    @Transactional
    public CountryResponse update(Long id, CountryUpdateRequest req) {
        CountryInfo c = repository.findById(id).orElseThrow(() -> new CountryNotFoundException(id));
        c.setName(req.name().trim());
        c.setCapitalCity(req.capitalCity());
        c.setPhoneCode(req.phoneCode());
        c.setContinentCode(req.continentCode());
        c.setCurrencyIsoCode(req.currencyIsoCode());
        c.setCountryFlag(req.countryFlag());
        if (req.languages() != null) {
            List<Language> langs = req.languages().stream().map(l -> new Language(l.isoCode(), l.name())).toList();
            c.replaceLanguages(langs);
        }
        CountryInfo saved = repository.saveAndFlush(c);
        log.info("Country updated id={}", id);
        return CountryResponse.from(saved);
    }

    @Transactional
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new CountryNotFoundException(id);
        }
        repository.deleteById(id);
        log.info("Country deleted id={}", id);
    }
}

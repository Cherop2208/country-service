package com.ncba.country.util;

import java.util.Arrays;
import java.util.Locale;
import java.util.stream.Collectors;

/** Normalises country names, e.g. "  kENYA " -> "Kenya", "south africa" -> "South Africa". */
public final class NameFormatter {

    private NameFormatter() {}

    public static String toSentenceCase(String input) {
        if (input == null) {
            return null;
        }
        String trimmed = input.trim().replaceAll("\\s+", " ");
        if (trimmed.isEmpty()) {
            return trimmed;
        }
        return Arrays.stream(trimmed.split(" "))
                .map(w -> w.substring(0, 1).toUpperCase(Locale.ROOT) + w.substring(1).toLowerCase(Locale.ROOT))
                .collect(Collectors.joining(" "));
    }
}

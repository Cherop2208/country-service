package com.ncba.country.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import java.time.Duration;

@Configuration
public class SoapClientConfig {

    @Bean
    public RestClient soapRestClient(@Value("${soap.country-info.url}") String url,
                                     @Value("${soap.country-info.connect-timeout-ms}") long connectTimeoutMs,
                                     @Value("${soap.country-info.read-timeout-ms}") long readTimeoutMs) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(Duration.ofMillis(connectTimeoutMs));
        factory.setReadTimeout(Duration.ofMillis(readTimeoutMs));
        return RestClient.builder().baseUrl(url).requestFactory(factory).build();
    }
}

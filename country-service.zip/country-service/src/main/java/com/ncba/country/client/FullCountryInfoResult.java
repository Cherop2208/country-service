package com.ncba.country.client;

import java.util.List;

/** Parsed result of the SOAP FullCountryInfo operation. */
public record FullCountryInfoResult(
        String isoCode,
        String name,
        String capitalCity,
        String phoneCode,
        String continentCode,
        String currencyIsoCode,
        String countryFlag,
        List<LanguageInfo> languages) {

    public record LanguageInfo(String isoCode, String name) {
    }
}

package com.ncba.country.client;

import com.ncba.country.exception.ExternalServiceException;
import com.ncba.country.exception.ServiceCircuitOpenException;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;

/**
 * Integration adapter for the SOAP CountryInfoService.
 * Protection layers: timeouts (RestClient) -> retry w/ backoff -> circuit breaker -> cache of successful lookups.
 */
@Component
public class CountryInfoSoapClient {

    private static final Logger log = LoggerFactory.getLogger(CountryInfoSoapClient.class);
    private static final String INSTANCE = "countryInfoSoap";

    private final RestClient restClient;
    private final MeterRegistry registry;

    public CountryInfoSoapClient(RestClient soapRestClient, MeterRegistry registry) {
        this.restClient = soapRestClient;
        this.registry = registry;
    }

    @Cacheable(cacheNames = "isoCodes", key = "#countryName")
    @Retry(name = INSTANCE)
    @CircuitBreaker(name = INSTANCE, fallbackMethod = "isoCodeFallback")
    public String fetchIsoCode(String countryName) {
        log.info("SOAP call CountryISOCode countryName={}", countryName);
        String response = post("CountryISOCode", SoapXml.isoCodeRequest(countryName));
        String iso = SoapXml.parseIsoCode(response, countryName);
        log.info("SOAP CountryISOCode resolved countryName={} isoCode={}", countryName, iso);
        return iso;
    }

    @Cacheable(cacheNames = "countryInfo", key = "#isoCode")
    @Retry(name = INSTANCE)
    @CircuitBreaker(name = INSTANCE, fallbackMethod = "fullInfoFallback")
    public FullCountryInfoResult fetchFullCountryInfo(String isoCode) {
        log.info("SOAP call FullCountryInfo isoCode={}", isoCode);
        String response = post("FullCountryInfo", SoapXml.fullCountryInfoRequest(isoCode));
        FullCountryInfoResult info = SoapXml.parseFullCountryInfo(response, isoCode);
        log.info("SOAP FullCountryInfo resolved isoCode={} name={} languages={}", isoCode, info.name(), info.languages().size());
        return info;
    }

    public String isoCodeFallback(String countryName, CallNotPermittedException ex) {
        throw new ServiceCircuitOpenException("Circuit open for CountryInfoService", ex);
    }

    public FullCountryInfoResult fullInfoFallback(String isoCode, CallNotPermittedException ex) {
        throw new ServiceCircuitOpenException("Circuit open for CountryInfoService", ex);
    }

    private String post(String operation, String body) {
        Timer.Sample sample = Timer.start(registry);
        String outcome = "success";
        try {
            String result = restClient.post()
                    .contentType(MediaType.parseMediaType("text/xml; charset=utf-8"))
                    .accept(MediaType.TEXT_XML, MediaType.APPLICATION_XML)
                    .header("SOAPAction", SoapXml.NS + "/" + operation)
                    .body(body)
                    .retrieve()
                    .body(String.class);
            if (result == null || result.isBlank()) {
                throw new ExternalServiceException("Empty SOAP response for " + operation);
            }
            return result;
        } catch (RestClientResponseException e) {
            outcome = "http_" + e.getStatusCode().value();
            throw new ExternalServiceException("SOAP " + operation + " returned HTTP " + e.getStatusCode().value(), e);
        } catch (ResourceAccessException e) {
            outcome = "io_error";
            throw new ExternalServiceException("SOAP " + operation + " unreachable or timed out", e);
        } catch (RuntimeException e) {
            outcome = "error";
            throw e;
        } finally {
            sample.stop(registry.timer("soap.client.calls", "operation", operation, "outcome", outcome));
        }
    }
}

package com.ncba.country.exception;

/** The SOAP service does not know the requested country / ISO code (maps to HTTP 404). */
public class UnknownCountryException extends RuntimeException {
    public UnknownCountryException(String message) {
        super(message);
    }
}
